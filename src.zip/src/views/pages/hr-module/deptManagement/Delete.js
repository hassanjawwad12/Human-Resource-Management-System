import React from 'react';
import { DeleteDepartment } from '../../../../store/hr/DepartmentSlice';
import { useState } from 'react';
import { useDispatch } from 'react-redux';
import DeleteIcon from '@mui/icons-material/Delete';
import { Dialog, DialogContent, DialogActions, Button, DialogTitle } from '@mui/material';
import { IconButton, Typography } from '@mui/material';
import AlertMessage from '../../../../components/shared/AlertMessage';

const Delete = ({ id, count, setCount }) => {
  const [open, setOpen] = React.useState(false);
  const dispatch = useDispatch();

  const [alert, setAlert] = useState({
    open: false,
    severity: '',
    message: '',
  });

  const handleDialogOpen = () => {
    setOpen(true);
  };

  const handleDialogClose = () => {
    setOpen(false);
  };

  const DeleteDept = () => {
    dispatch(DeleteDepartment(id))
      .then((result) => {
        if (result.payload.USER_MESSAGE === 'Designation Deleted') {
          setAlert({
            open: true,
            severity: 'success',
            message: 'Dept Deleted successfully',
          });
          setCount(count + 1);
          handleDialogClose();
        } else {
          setAlert({
            open: true,
            severity: 'error',
            message: 'Failed to delete department',
          });
        }
      })
      .catch((err) => {
        setAlert({
          open: true,
          severity: 'error',
          message: 'Something went wrong.',
        });
      });
  };

  return (
    <div>
      <AlertMessage
        open={alert.open}
        setAlert={setAlert}
        severity={alert.severity}
        message={alert.message}
      />

      <IconButton onClick={handleDialogOpen} sx={{ color: 'red' }} aria-label="delete designation">
        <DeleteIcon sx={{ width: 25, height: 25 }} />
      </IconButton>
      <Dialog open={open} onClose={handleDialogClose} maxWidth="sm" fullWidth>
        <DialogTitle sx={{ bgcolor: 'primary.main', py: 2 }}>
          <Typography variant="h4" className="text-white">
            Confirm Delete
          </Typography>
        </DialogTitle>
        <DialogContent>
          <div className="flex flex-col items-center justify-center w-full h-full gap-4 mt-4 pt-4">
            <Typography variant="h5" fontWeight={800}>
              Are you sure you want to delete the Department?
            </Typography>
          </div>
        </DialogContent>
        <DialogActions sx={{ display: 'flex', justifyContent: 'space-between', px: 3, py: 2 }}>
          <Button
            variant="outlined"
            onClick={handleDialogClose}
            sx={{ color: 'primary.main', bgcolor: '#fff !important', borderColor: 'primary.main' }}
          >
            Cancel
          </Button>
          <Button onClick={DeleteDept} variant="outlined" sx={{ color: 'white' }}>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Delete;

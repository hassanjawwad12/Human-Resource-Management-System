export const BASE_URL = 'http://122.248.194.140:8081/'


